import sqlite3
import random
import pandas as pd
import time
import matplotlib.pyplot as plt

# Create SQLite connection
conn = sqlite3.connect('vehicle_data.db')
c = conn.cursor()

# Create a table to store vehicle data (with additional parameters)
c.execute('''CREATE TABLE IF NOT EXISTS vehicle_data (
                 vehicle_id INTEGER,
                 timestamp TEXT,
                 oil_temperature REAL,
                 coolant_temperature REAL,
                 oil_pressure REAL,
                 coolant_pressure REAL,
                 rpm INTEGER
             )''')
conn.commit()


# simulate RPMs with gradual changes
def simulate_rpm(last_rpm, is_idling=False, is_engine_off=False, is_staying_off=False):
    if is_engine_off or is_staying_off:
        return 0  # RPM is 0 when the engine is off
    if is_idling:
        return 800  # RPM is low when idling

    # Small random change to RPM within operating bounds
    change = random.randint(-100, 100)
    new_rpm = last_rpm + change
    return max(1200, min(4000, new_rpm))


# simulate oil temperature
def simulate_oil_temperature(last_temp, rpm, is_engine_off=False):
    if is_engine_off:
        temp_change = random.uniform(-0.3, -0.1)  # Gradual cooling when engine is off
    else:
        temp_change = random.uniform(-0.01, 0.01)  # Small fluctuation
        temp_change += (rpm - 1500) * 0.002  # Effect of RPM on oil temperature

        # Rare event for temperature spike
        if random.random() < 0.0005:
            temp_change = random.uniform(10, 18)

    new_temp = last_temp + temp_change
    return max(90, min(120, new_temp))


# simulate coolant temperature
def simulate_coolant_temperature(last_temp, is_engine_off=False):
    if is_engine_off:
        temp_change = random.uniform(-0.2, -0.05)  # Gradual cooling when off
    else:
        temp_change = random.uniform(-0.01, 0.01)  # Small fluctuation

        # Rare overheating event
        if random.random() < 0.0003:
            temp_change = random.uniform(10, 20)

    new_temp = last_temp + temp_change
    return max(85, min(95, new_temp))


# simulate oil pressure
def simulate_oil_pressure(rpm, is_engine_off=False):
    if is_engine_off:
        return 0  # Pressure drops to 0 when engine is off
    # Pressure increases with RPM
    return round(40 + (rpm - 1500) * 0.01, 2)


# simulate coolant pressure
def simulate_coolant_pressure(coolant_temp, is_engine_off=False):
    if is_engine_off:
        return 0  # Coolant pressure drops when engine is off
    # Pressure based on coolant temperature
    return round(10 + (coolant_temp - 90) * 0.1, 2)


# log data into SQLite
def log_vehicle_data(vehicle_id, oil_temp, coolant_temp, oil_pressure, coolant_pressure, rpm):
    timestamp = time.strftime('%Y-%m-%d %H:%M:%S')
    c.execute('''INSERT INTO vehicle_data (
                    vehicle_id, timestamp, oil_temperature, coolant_temperature, 
                    oil_pressure, coolant_pressure, rpm) 
                 VALUES (?, ?, ?, ?, ?, ?, ?)''',
              (vehicle_id, timestamp, oil_temp, coolant_temp, oil_pressure, coolant_pressure, rpm))
    conn.commit()


# Define the total simulation time
total_runtime = 120

# Initialize vehicle parameters
vehicle_temps = {vehicle_id: random.uniform(90, 95) for vehicle_id in range(1, 6)}
coolant_temps = {vehicle_id: random.uniform(88, 92) for vehicle_id in range(1, 6)}
vehicle_rpms = {vehicle_id: random.randint(1500, 2000) for vehicle_id in range(1, 6)}
oil_pressures = {vehicle_id: simulate_oil_pressure(vehicle_rpms[vehicle_id]) for vehicle_id in range(1, 6)}
coolant_pressures = {vehicle_id: simulate_coolant_pressure(coolant_temps[vehicle_id]) for vehicle_id in range(1, 6)}

# Initialize vehicle states (for idling, engine off, and staying off)
vehicle_idle_state = {vehicle_id: False for vehicle_id in range(1, 6)}
vehicle_engine_off_state = {vehicle_id: False for vehicle_id in range(1, 6)}
vehicle_staying_off_timer = {vehicle_id: 0 for vehicle_id in range(1, 6)}

# Get the current time to mark the start
start_time = time.time()

# Run the simulation for the specified time period
while time.time() - start_time < total_runtime:
    for vehicle_id in range(1, 6):  # Simulating data for 5 vehicles
        # Handle the case where the vehicle is staying off
        if vehicle_staying_off_timer[vehicle_id] > 0:
            vehicle_staying_off_timer[vehicle_id] -= 1
            vehicle_engine_off_state[vehicle_id] = True
            continue  # Skip updates for this vehicle

        # Reset engine state if the timer has expired
        vehicle_engine_off_state[vehicle_id] = False

        # Random chance for idling (2% chance per iteration)
        if random.random() < 0.02:
            vehicle_idle_state[vehicle_id] = True
        else:
            vehicle_idle_state[vehicle_id] = False

        # Reduced chance for engine off (0.5% chance per iteration)
        if random.random() < 0.005:
            vehicle_staying_off_timer[vehicle_id] = random.randint(5, 10)
            vehicle_engine_off_state[vehicle_id] = True
            continue  # Skip updating RPM and temperature since engine just turned off

        # Simulate new values for RPM, oil temperature, coolant temperature, oil pressure, and coolant pressure
        new_rpm = simulate_rpm(vehicle_rpms[vehicle_id],
                               is_idling=vehicle_idle_state[vehicle_id],
                               is_engine_off=vehicle_engine_off_state[vehicle_id])
        new_oil_temp = simulate_oil_temperature(vehicle_temps[vehicle_id], new_rpm,
                                                is_engine_off=vehicle_engine_off_state[vehicle_id])
        new_coolant_temp = simulate_coolant_temperature(coolant_temps[vehicle_id],
                                                        is_engine_off=vehicle_engine_off_state[vehicle_id])
        new_oil_pressure = simulate_oil_pressure(new_rpm, is_engine_off=vehicle_engine_off_state[vehicle_id])
        new_coolant_pressure = simulate_coolant_pressure(new_coolant_temp,
                                                         is_engine_off=vehicle_engine_off_state[vehicle_id])

        # Update the vehicle's current parameters
        vehicle_temps[vehicle_id] = new_oil_temp
        coolant_temps[vehicle_id] = new_coolant_temp
        vehicle_rpms[vehicle_id] = new_rpm
        oil_pressures[vehicle_id] = new_oil_pressure
        coolant_pressures[vehicle_id] = new_coolant_pressure

        # Log the new data
        log_vehicle_data(vehicle_id, new_oil_temp, new_coolant_temp, new_oil_pressure, new_coolant_pressure, new_rpm)

    time.sleep(1)  # Simulate real-time logging with a 1-second interval

print(f"Simulation stopped after {total_runtime} seconds.")

# Close the database connection after data logging
conn.close()


# Reopen SQLite connection for data analysis
conn = sqlite3.connect('vehicle_data.db')

# Read data into pandas dataframe
df = pd.read_sql_query("SELECT * FROM vehicle_data", conn)

# Convert 'timestamp' to datetime format
df['timestamp'] = pd.to_datetime(df['timestamp'])

# Plotting data
plt.figure(figsize=(12, 12))

# Oil Temperature Plot
plt.subplot(3, 1, 1)
for vehicle_id in df['vehicle_id'].unique():
    vehicle_data = df[df['vehicle_id'] == vehicle_id]
    plt.plot(vehicle_data['timestamp'], vehicle_data['oil_temperature'], label=f'Vehicle {vehicle_id}')
plt.title('Oil Temperature per Vehicle')
plt.ylabel('Oil Temperature (°C)')
plt.xticks(rotation=45)
plt.legend()

# Coolant Temperature Plot
plt.subplot(3, 1, 2)
for vehicle_id in df['vehicle_id'].unique():
    vehicle_data = df[df['vehicle_id'] == vehicle_id]
    plt.plot(vehicle_data['timestamp'], vehicle_data['coolant_temperature'], label=f'Vehicle {vehicle_id}')
plt.title('Coolant Temperature per Vehicle')
plt.ylabel('Coolant Temperature (°C)')
plt.xticks(rotation=45)

# Oil Pressure Plot
plt.subplot(3, 1, 3)
for vehicle_id in df['vehicle_id'].unique():
    vehicle_data = df[df['vehicle_id'] == vehicle_id]
    plt.plot(vehicle_data['timestamp'], vehicle_data['oil_pressure'], label=f'Vehicle {vehicle_id}')
plt.title('Oil Pressure per Vehicle')
plt.ylabel('Oil Pressure (PSI)')
plt.xlabel('Timestamp')
plt.xticks(rotation=45)

plt.tight_layout()
plt.show()

# Close the SQLite connection
conn.close()
