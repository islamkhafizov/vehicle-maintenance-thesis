import matplotlib.pyplot as plt
import networkx as nx

G = nx.DiGraph()

nodes = [
    "Telemetry Data (CSV Files)", "Data Ingestion", "Data Preprocessing",
    "Feature Selection", "Model Training", "Fault Prediction", "Visualization (Graphs)"
]
G.add_nodes_from(nodes)

edges = [
    ("Telemetry Data (CSV Files)", "Data Ingestion"),
    ("Data Ingestion", "Data Preprocessing"),
    ("Data Preprocessing", "Feature Selection"),
    ("Feature Selection", "Model Training"),
    ("Model Training", "Fault Prediction"),
    ("Fault Prediction", "Visualization (Graphs)")
]
G.add_edges_from(edges)

plt.figure(figsize=(12, 8))
pos = nx.spring_layout(G)
nx.draw(
    G, pos, with_labels=True, node_size=4000, node_color="lightblue",
    font_size=10, font_weight="bold", arrowsize=20
)
plt.title("Data Flow Diagram for Predictive Maintenance System")
plt.show()